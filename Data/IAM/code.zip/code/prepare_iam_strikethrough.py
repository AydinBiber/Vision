"""
Prepares the dataset as it was used in the associated paper.

Merges the clean image with the extracted strikethrough stroke to reconstruct the synthetic strikethrough database.
Collects and copies the unaltered images for the clean and ground truth directories.
"""
import shutil
from pathlib import Path

import numpy as np
from skimage.io import imread, imsave
from skimage.util import img_as_int, img_as_ubyte

wordsDirectory = Path("IAM/words")  # should point to the IAM 'words' directory
dataDirectory = Path("zenodo/IAM_strikethrough")  # should point to the directory containing the data from zenodo
outputDirectory = Path("out/IAM_striekthrough")  # point to where the merged images should be saved


def getSourcePath(imageID):
    imageName = "{}.png".format(imageID)
    components = imageID.split("-")
    source = wordsDirectory / components[0] / "{}-{}".format(components[0], components[1]) / imageName
    return source


for datasplit in ['train', 'validation', 'test']:
    for directory in ['clean', 'struck', 'struck_gt']:
        datasplitOutDir = outputDirectory / datasplit / directory
        datasplitOutDir.mkdir(exist_ok=True, parents=True)

        sourceDir = dataDirectory / datasplit / directory

        csvs = list(sourceDir.glob("*.csv"))
        if len(csvs) == 1:
            source = csvs[0]
            destination = datasplitOutDir / source.name
            shutil.copy2(source, destination)

        for imagePath in sourceDir.glob("*.npy"):
            diff = np.load(imagePath, allow_pickle=False)
            imageName = '{}.png'.format(imagePath.stem)
            iam_path = getSourcePath(imagePath.stem)
            original = img_as_int(imread(iam_path))
            altered = img_as_ubyte(diff + original)
            imgDest = datasplitOutDir / imageName
            imsave(imgDest, altered)
