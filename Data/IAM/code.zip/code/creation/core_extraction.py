"""
Core extraction based on:

A. Papandreou, B. Gatos,
Slant estimation and core-region detection for handwritten Latin words,
Pattern Recognition Letters, Volume 35, 2014, Pages 16-22, ISSN 0167-8655,
https://doi.org/10.1016/j.patrec.2012.08.005.

Implemented by R.Heil, 2021
"""

import itertools

import numpy as np


def __run_count__(line, ink_value=255):
    groups = []
    for _, g in itertools.groupby(line, lambda x: x == ink_value):
        groups.append(list(g))
    count = len([x for x in groups if ink_value in x])
    return count


def __count_runs__(image):
    return np.apply_along_axis(__run_count__, axis=1, arr=image)


def __calc_thresh__(lines, t=0.15):
    return t / len(lines) * sum(lines)


def __find_core_region__(h_binary, h_y):
    total = []
    borders = []
    current = 0
    start = 0
    for i, x in enumerate(h_binary):
        if current == 0:
            start = i
        if x == 1:
            current += h_y[i]
        else:
            if current > 0:
                total.append(current)
                borders.append((start, i - 1))
                current = 0
                start = i + 1
    if current > 0:
        total.append(current)
        borders.append((start, len(h_binary) - 1))

    return borders[np.argmax(total)]


def extract_core_region(image, threshold_modifier=0.15):
    h_profile = np.sum(image, 1)
    counts = __count_runs__(image)

    h_y = counts * h_profile * h_profile

    t = __calc_thresh__(h_y, threshold_modifier)
    h_binary = (h_y > t) * 1

    return __find_core_region__(h_binary, h_y)
