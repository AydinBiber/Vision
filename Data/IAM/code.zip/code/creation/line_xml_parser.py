"""
Parses the IAM XML representation and selects one form per writer per dataset to be used for further processing by
image_picker.py and subsequently struck_generator.py.

Requires paths to the official IAM data split files for the 'Large Writer Independent Text Line Recognition Task'
(cf. https://fki.tic.heia-fr.ch/databases/iam-handwriting-database section "Tasks"), the IAM XML folder and an output
path.
"""
import xml.etree.ElementTree as ET
from pathlib import Path

import pandas as pd

testset = Path('largeWriterIndependentTextLineRecognitionTask/testset.txt')
trainset = Path('largeWriterIndependentTextLineRecognitionTask/trainset.txt')
validationset1 = Path('largeWriterIndependentTextLineRecognitionTask/validationset1.txt')
validationset2 = Path('largeWriterIndependentTextLineRecognitionTask/validationset2.txt')

xml_path = Path('xml')
out_path = Path('out')

sets = [testset, trainset, validationset1, validationset2]

for input_set in sets:
    print(input_set.name)
    set_info = pd.read_csv(input_set, header=None)
    set_info.columns = ['form_id']
    for line in set_info.iloc:
        filename = Path(line[0])
        basic = filename.name
        line[0] = basic[0:-3]
    set_info = set_info.drop_duplicates().reset_index(drop=True)
    set_info['writer_id'] = [-1 for line in set_info.iloc]
    for entry in set_info.iloc:
        page_path = (xml_path / entry['form_id']).with_suffix('.xml')
        tree = ET.parse(page_path)
        root = tree.getroot()
        writer_id = root.attrib['writer-id']
        set_info.at[entry.name, 'writer_id'] = writer_id

    writer_dict = set_info.groupby('writer_id').apply(lambda g: [x.to_dict() for x in g.iloc]).to_dict()
    form_dict = {}
    for writer in writer_dict.keys():
        def run(form_ids):
            for id in form_ids:
                if id['form_id'] not in form_dict.keys():
                    return id['form_id']
            return -1


        form_ids = writer_dict[writer]
        form_id = run(form_ids)
        if form_id != -1:
            form_dict[form_id] = writer
        else:
            print(-1)

    print(len(form_dict.keys()))
    tuple_list = [(form_dict[x], x) for x in form_dict.keys()]
    df = pd.DataFrame(tuple_list, columns=['writer_id', 'form_id'])
    p = (out_path / input_set.stem).with_suffix('.csv')
    df.to_csv(p, index=False)
