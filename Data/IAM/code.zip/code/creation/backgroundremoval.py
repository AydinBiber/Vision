"""
Code to remove background noise from a handwritten word image. Original code by Anders Hast (anders.hast@it.uu.se),
adapted to Python by Raphaela Heil (raphaela.heil@it.uu.se).

See also: P. Singh, E. Vats and A. Hast, "Learning Surrogate Models of Document Image Quality Metrics for Automated
Document Image Processing," 2018 13th IAPR International Workshop on Document Analysis Systems (DAS), 2018, pp. 67-72,
doi: 10.1109/DAS.2018.14.
"""

from math import ceil

import numpy as np
from scipy import signal
from skimage import filters


def calculateGaussianKernel(width=5, sigma=1.):
    ax = np.arange(-width // 2 + 1., width // 2 + 1.)
    xx, yy = np.meshgrid(ax, ax)

    kernel = np.exp(-0.5 * (np.square(xx) + np.square(yy)) / np.square(sigma))

    return kernel / np.sum(kernel)


def calculateMaskParameters(So, sz):
    if type(So) == tuple:
        if sz == 0:
            kernelSize = ceil(max(So))
        else:
            scale = min(So) / sz
            width = ceil(So[0] / scale)
            height = ceil(So[1] / scale)
            kernelSize = ceil(max((width, height)))

        if kernelSize % 2 == 0:
            kernelSize = kernelSize + 1

        sigma = kernelSize / 6.0
    else:
        if sz == 0:
            kernelSize = ceil(So)
        else:
            scale = So / sz
            kernelSize = ceil(So / scale)

        if kernelSize % 2 == 0:
            kernelSize = kernelSize + 1

        sigma = kernelSize / 6.0

    return kernelSize, sigma


def applyFilters(image: np.ndarray, so, sz: int) -> np.ndarray:
    imageShape = image.shape
    N, sigma = calculateMaskParameters(so, sz)
    kernel = calculateGaussianKernel(N, sigma)
    divisor = signal.fftconvolve(np.ones(imageShape).astype('float'), kernel, 'same')
    numerator = signal.fftconvolve(image.astype('float'), kernel, 'same')
    filteredImage = np.divide(numerator, divisor)
    return filteredImage


def blurryBandpassFilter(image: np.ndarray, blurringMaskSize: int, threshold: float) -> np.ndarray:
    if blurringMaskSize > 1:
        thickMask = applyFilters(image, blurringMaskSize, 0)
    else:
        thickMask = image

    p2 = applyFilters(image, image.shape, 300)
    im2 = p2 - thickMask

    th2 = filters.threshold_otsu(p2 - thickMask)
    thresholdedImage = im2 > (th2 * threshold)
    return thresholdedImage


def thinBandpassFilter(image, noiseMaskSize, enhanceContrast) -> np.ndarray:
    if noiseMaskSize > 1:
        thinMask = applyFilters(image, noiseMaskSize, 0)
    else:
        thinMask = image

    p2 = applyFilters(image, image.shape, 100)
    im2 = p2 - thinMask

    nim2 = np.zeros(im2.shape)
    nim2[im2 > 0] = im2[im2 > 0]

    if enhanceContrast:
        nim2 = nim2 - nim2.min()
        nim2 = nim2 / nim2.max()

    return nim2


def backgroundRemoval(image: np.ndarray, blurringMaskSize: int, noiseMaskSize: int, threshold: float,
                      enhanceContrast: bool) -> np.ndarray:
    """
    Applies the background removal to the given image, which should be in the range of [0,255].
    """
    nim1 = blurryBandpassFilter(image, blurringMaskSize, threshold)
    nim2 = thinBandpassFilter(image, noiseMaskSize, enhanceContrast)

    if enhanceContrast:
        nim2 = nim2 - nim2.min()
        nim2 = nim2 / nim2.max()

    result = 255 - (nim1 * nim2)

    return result
