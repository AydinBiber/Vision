This directory contains the exact code that has been used to generate the data used in the paper "Strikethrough Removal From Handwritten Words Using CycleGANs" by R.Heil, E.Vats and A.Hast, ICDAR 2021.

If you find this code useful, please cite the aforementioned work :)

:warning: If you intend to use the strikethrough generation on your own data, it is strongly recommended that you refer
to [https://github.com/RaphaelaHeil/strikethrough-generation](https://github.com/RaphaelaHeil/strikethrough-generation),
which has more in-depth documentation and will have the latest updates, if any.

### Running this code
This code consists of several scripts that have to be executed after each other. Please follow the steps below:
0. Install required packages (originally used versions in parentheses):
   - opencv-python (4.5.1.48)
   - numpy (1.19.5)
   - imgaug (0.4.0)
   - scipy (1.5.4)
   - scikit-image (0.17.2)
1. define the required paths in the script and run [line_xml_parser.py](line_xml_parser.py)
2. define the required paths in the script and run [image_picker.py](image_picker.py)
3. define the required paths in the script and run [struck_generator.py](struck_generator.py)
