"""
Copies previously selected images to respective sub directories <datasplit>/[clean, struck, struck_gt] and applies
generated strikethrough strokes, where applicable (i.e. for the "struck" subdir).

Expects two paths as input:
1) -input: the path to the directory containing the IAM 'xml' and 'words' directories, as well as the files generated
by the previously run script, image_picker.py (i.e. one json file per datasplit, containing the struck and clean image
names per writer id)
2) -output: path to output directory
"""
import argparse
import csv
import json
import random
import shutil
from pathlib import Path

import cv2
import numpy as np

from backgroundremoval import backgroundRemoval
from generator import StrikeThroughGenerator, StrikeThroughType


def get_source_path(word_dir_path, image_name):
    upper_dir = image_name[0:3]
    lower_dir = image_name[:-6]
    p = (word_dir_path / upper_dir / lower_dir / image_name).with_suffix('.png')
    return p


def removeBackground(original):
    bgr_original = backgroundRemoval(original, 1.0, 5.0, 0.0, False)
    mask = (bgr_original != 255)
    bgr_removed = np.ones_like(bgr_original) * 255
    bgr_removed[mask] = original[mask]
    return bgr_removed


if __name__ == '__main__':
    cmdParser = argparse.ArgumentParser()
    cmdParser.add_argument("-input", required=True, help="Path to input data directory")
    cmdParser.add_argument("-output", required=True, help="Path to output directory")
    args = vars(cmdParser.parse_args())


    in_path = Path(args['input'])
    out_top_dir = Path(args['output'])

    sets = ['test','train', 'validation']
    seeds = [1347340, 1282728, 1236168]

    for set_name, seed in zip(sets,seeds ):
        input_file = in_path / '{}set.json'.format(set_name)
        original_path = in_path / 'words'
        out_base_path = out_top_dir / '{}'.format(set_name)
        clean_path = out_base_path / 'clean'

        if not clean_path.exists():
            clean_path.mkdir(parents=True, exist_ok=True)
        struck_path = out_base_path / 'struck'
        if not struck_path.exists():
            struck_path.mkdir(parents=True, exist_ok=True)

        if set_name != 'train':
            struck_gt_path = out_base_path / 'struck_gt'
            if not struck_gt_path.exists():
                struck_gt_path.mkdir(parents=True, exist_ok=True)

        with open(input_file) as infile:
            data = json.load(infile)

        clean_csv = clean_path / 'clean_{}.csv'.format(set_name)
        struck_csv = struck_path / 'struck_{}.csv'.format(set_name)

        clean_data = [['image_id', 'writer_id']]
        struck_data = [['image_id', 'writer_id', 'strike_type']]

        generator = StrikeThroughGenerator(seed=seed)

        keys = list(data.keys())
        key_count = len(keys)
        print(key_count)
        img_entry_count = len(data[keys[0]]['struck'])

        for entry in data.items():
            writer_id = '{:03d}'.format(int(entry[0]))
            struck_files = entry[1]['struck']
            clean_names = entry[1]['clean']
            for clean in clean_names:
                img_source = get_source_path(original_path, clean)
                img_destination = clean_path / img_source.name
                original = cv2.imread(str(img_source), cv2.CV_8UC1)
                output = removeBackground(original)
                cv2.imwrite(str(img_destination), output)

                clean_data.append([clean, writer_id])

            strikethrough_type_pool = list(range(0, 7)) * int(len(struck_files) / 7)
            random.shuffle(strikethrough_type_pool)

            for struck, strikethrough_type_id in zip(struck_files, strikethrough_type_pool):
                img_source = get_source_path(original_path, struck)
                if set_name != 'train':
                    shutil.copy(str(img_source), str(struck_gt_path / img_source.name))
                original = cv2.imread(str(img_source), cv2.CV_8UC1)
                output, strike_type = generator.generate_struck_word(original, StrikeThroughType(strikethrough_type_id))
                cv2.imwrite(str(struck_path / img_source.name), output)
                struck_data.append([struck, writer_id, strike_type.name])

        with open(clean_csv, 'w') as outfile:
            writer = csv.writer(outfile)
            writer.writerows(clean_data)

        with open(struck_csv, 'w') as outfile:
            writer = csv.writer(outfile)
            writer.writerows(struck_data)
