"""
Selects a number of images per writer per dataset and writes their names to a file to be used for the strikethrough
generation.
Basepath should contain a directory called 'xml', contianing the XML representations for IAM, as well as the csv files
produced by line_xml_parser.py.
"""
import json
import random
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import pandas as pd

random.seed(910)

input_sets = [('testset.csv', 7), ('trainset.csv', 14), ('validationset.csv', 7)]

basePath = Path('.')  # should point to the parent of the directory that contains the xml records for IAM
xml_path = basePath / "xml"

if not xml_path.exists():
    print("<basePath>/xml does not exist - please verify setup")
    exit()


def get_source_path(word_dir_path, image_name):
    upper_dir = image_name[0:3]
    lower_dir = image_name[:-6]
    p = (word_dir_path / upper_dir / lower_dir / image_name).with_suffix('.png')
    return p


for input_set in input_sets:
    set_file_name = input_set[0]
    count = input_set[1]
    forms_and_writers = pd.read_csv(basePath / set_file_name)
    output_dict = {}
    for entry in forms_and_writers.iloc:
        file_path = (xml_path / entry['form_id']).with_suffix('.xml')
        tree = ET.parse(file_path)
        root = tree.getroot()
        handwritten = root[1]
        available_ids = []
        for lines in handwritten:
            for word in lines:
                if word.tag == 'word':
                    if '#' not in word.attrib['text']:
                        total_width = 0
                        max_height = 0
                        for cmp in word:
                            height = int(cmp.attrib['height'])
                            if height > max_height:
                                max_height = height
                            total_width += int(cmp.attrib['width'])
                        if max_height > 60 and total_width > 60:
                            img = cv2.imread(str(get_source_path(basePath / 'words', word.attrib['id'])))
                            if img is not None:
                                actual_size = img.shape
                                if 60 < actual_size[0] < 600 and 60 < actual_size[1] < 600:
                                    available_ids.append(word.attrib['id'])
                                else:
                                    print('size error', word.attrib['id'])
                            else:
                                print('img loading error', word.attrib['id'])
        if len(available_ids) < count * 2:
            print(entry['form_id'])
            print(len(available_ids))
            continue
        random.shuffle(available_ids)
        sample = random.sample(available_ids, count * 2)
        random.shuffle(sample)
        strike = sample[0:count]
        clean = sample[count:]
        output_dict[str(entry['writer_id'])] = {'struck': strike, 'clean': clean}
    with open((basePath / set_file_name[:-4]).with_suffix('.json'), 'w') as outfile:
        json.dump(output_dict, outfile, indent=2)
