import itertools
import logging
from enum import Enum
from math import floor
from typing import List

import cv2
import numpy as np
from imgaug.augmenters import ElasticTransformation
from scipy import interpolate

from backgroundremoval import backgroundRemoval
from core_extraction import extract_core_region


class StrikeThroughType(Enum):
    SINGLE_LINE = 0
    DOUBLE_LINE = 1
    DIAGONAL = 2
    CROSS = 3
    WAVE = 4
    ZIG_ZAG = 5
    SCRATCH = 6


class StrikeThroughGenerator:
    TRANSFORM = ElasticTransformation(alpha=(0, 20.0), sigma=(4.0, 6.0))

    def __init__(self, options=None, draw_from=None, seed=None):
        np.random.seed(seed)
        if draw_from is None:
            self.draw_from = list(StrikeThroughType)
        else:
            self.draw_from = draw_from
        if options:
            self.options = options
        else:
            self.options = {'pad': 10}

    def generate_struck_word(self, original, strike_type=None):
        if not strike_type:
            strike_type = np.random.choice(self.draw_from)

        height, width = original.shape
        original = 255 - self.removeBackground(original).astype(np.uint8)
        binary_image = self._binarise(original)
        stroke_width = self._get_stroke_width(binary_image)
        core_region = extract_core_region(binary_image)
        image_dt = self._dt(binary_image)
        average_ink_value = self._calculate_average_ink_value(original)

        if strike_type == StrikeThroughType.SINGLE_LINE:
            line_coords = self._single_line(height, width, core_region)
            line_profile = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords)], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_dt = self._line_dt(line_profile, self.options['pad'])
            line = self._generate_stroke_from_dt(original, image_dt, line_dt)
            strike_through = self._deform_line(line)
        elif strike_type == StrikeThroughType.DOUBLE_LINE:
            line_coords = self._double_line(height, width, core_region)
            line_profile = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords[0:2])], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_profile = cv2.polylines(line_profile, [np.array(line_coords[2:4])], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_dt = self._line_dt(line_profile, self.options['pad'])
            line = self._generate_stroke_from_dt(original, image_dt, line_dt)
            strike_through = self._deform_line(line)
        elif strike_type == StrikeThroughType.DIAGONAL:
            line_coords = self._diagonal(height, width)
            line_profile = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords[0:2])], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_profile = cv2.polylines(line_profile, [np.array(line_coords[2:4])], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_dt = self._line_dt(line_profile, self.options['pad'])
            line = self._generate_stroke_from_dt(original, image_dt, line_dt)
            strike_through = self._deform_line(line)
        elif strike_type == StrikeThroughType.CROSS:
            line_coords = self._cross(height, width, core_region=core_region)
            line_profile_1 = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords[0:2])], 0, (255, 255, 255),
                                           thickness=int(stroke_width))
            line_profile_2 = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords[2:4])], 0, (255, 255, 255),
                                           thickness=int(stroke_width))
            line_dt_1 = self._line_dt(line_profile_1, self.options['pad'])
            line_dt_2 = self._line_dt(line_profile_2, self.options['pad'])
            line_1 = self._generate_stroke_from_dt(original, image_dt, line_dt_1)
            line_2 = self._generate_stroke_from_dt(original, image_dt, line_dt_2)
            line = np.zeros(original.shape, dtype=np.int32)
            line += line_1
            line += line_2
            line = np.clip(line, 0, 255)
            strike_through = self._deform_line(line.astype(np.uint8))
        elif strike_type == StrikeThroughType.WAVE:
            line_coords = self._wave(height, width, core_region=core_region)
            line_profile = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords)], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_dt = self._line_dt(line_profile, self.options['pad'])
            line = self._generate_stroke_from_dt(original, image_dt, line_dt)
            strike_through = self._deform_line(line)
        elif strike_type == StrikeThroughType.ZIG_ZAG:
            line_coords = self._zig_zag(height, width, core_region=core_region)
            line_profile = cv2.polylines(np.zeros_like(image_dt), [np.array(line_coords)], 0, (255, 255, 255),
                                         thickness=int(stroke_width))
            line_dt = self._line_dt(line_profile, self.options['pad'])
            line = self._generate_stroke_from_dt(original, image_dt, line_dt)
            strike_through = self._deform_line(line)
        elif strike_type == StrikeThroughType.SCRATCH:
            line_segments = self._scratch(height, width, core_region=core_region)
            line_images = []
            prev_x = line_segments[0][0]
            prev_y = line_segments[0][1]
            for i in range(1, len(line_segments)):
                curr_x = line_segments[i][0]
                curr_y = line_segments[i][1]
                canvas = np.zeros(original.shape)
                cv2.line(canvas, (prev_x, prev_y), (curr_x, curr_y), (255, 255, 255), thickness=int(stroke_width))
                canvas_dt = self._line_dt(canvas)
                generated_stroke = self._generate_stroke_from_dt(original, image_dt, canvas_dt)
                line_images.append(generated_stroke)
                prev_x = curr_x
                prev_y = curr_y
            total = np.sum(np.array(line_images), axis=0)
            total[total > 255] = 255
            strike_through = self._deform_line(total.astype(np.uint8))
        else:
            raise NotImplementedError('No implementation found for {}'.format(strike_type))
        return (255 - self._superimpose(original, strike_through, average_ink_value)), strike_type

    def removeBackground(self, original):
        bgr_original = backgroundRemoval(original, 1.0, 5.0, 0.0, False)
        mask = (bgr_original != 255)
        bgr_removed = np.ones_like(bgr_original) * 255
        bgr_removed[mask] = original[mask]
        return bgr_removed

    def _calculate_average_ink_value(self, original):
        tmp = original.copy()
        tmp = tmp > 0.0
        return floor(np.sum(original) / (np.sum(tmp) + 0.000001))

    def _superimpose(self, original, strike_through, average_ink_value):
        superimposedImage = original.copy().astype(np.float32)

        maxInkValue = superimposedImage.max()
        factor = average_ink_value / maxInkValue

        line = strike_through.copy()
        tmp = superimposedImage + line
        indices = np.logical_and(superimposedImage > average_ink_value, line > average_ink_value)
        tmp[indices] = (superimposedImage[indices] + line[indices] * factor)

        tmp2 = tmp.copy()
        tmp2 = cv2.GaussianBlur(tmp2, (3, 3), 0.8)
        tmp[line > 0] = tmp2[line > 0]
        tmp = np.clip(tmp, 0, 255)

        return tmp.astype(np.uint8)

    def _generate_stroke_from_dt(self, original, image_dt, line_dt):
        synthetic_line = np.zeros_like(original)
        distances = np.unique(line_dt)[1:]
        draw_from = original
        for val in distances:
            colour_pool = draw_from[image_dt == val]
            if len(colour_pool) == 0:
                colour_pool = draw_from[image_dt > 0]
            indices = np.argwhere(line_dt == val)
            for index in indices:
                synthetic_line[index[0], index[1]] = np.random.choice(colour_pool)
        return synthetic_line

    def _binarise(self, image):
        _, binarised = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return binarised

    def _line_dt(self, line_image, pad=10):
        height, width = line_image.shape
        padded_line = np.zeros((height + 2 * pad, width + 2 * pad), dtype=np.uint8)
        padded_line[pad:pad + height, pad:pad + width] = line_image[:, :]
        line_dt = self._dt(padded_line)
        line_dt = line_dt[pad:pad + height, pad:pad + width]
        return line_dt

    def _dt(self, image):
        return cv2.distanceTransform(image, cv2.DIST_L2, 5)

    def _deform_line(self, line):
        deformed_line = self.TRANSFORM.augment_image(line)
        return deformed_line

    def _run_length(self, line, ink_value=255):
        groups = []
        for _, g in itertools.groupby(line, lambda x: x == ink_value):
            groups.append(list(g))
        length = [len(x) for x in groups if ink_value in x]
        return length

    def _get_stroke_width(self, binary_image):
        lengths = []
        height, width = binary_image.shape
        for i in range(height):
            line = binary_image[i]
            lengths.extend(self._run_length(line))
        for j in range(width):
            line = binary_image[:, j]
            lengths.extend(self._run_length(line))
        img_med = np.median(lengths)
        return img_med * 0.75

    def _single_line(self, height, width, core_region):
        min_width = int(width * 0.75)
        max_height = 10
        core_pad = int((core_region[1] - core_region[0]) * 0.1)
        x1 = np.random.randint(0, floor(width * 0.1))
        y1 = np.random.randint(core_region[0] + core_pad, core_region[1] - core_pad)
        x2 = np.random.randint(x1 + min_width, width)
        y2 = np.random.randint(y1 - int(0.5 * max_height), y1 + int(max_height * 0.5))
        if x2 > width:
            x2 = width
        if y2 > height:
            y2 = height
        return np.array([[x1, y1], [x2, y2]])

    def _double_line(self, height, width, core_region):
        first_line = self._single_line(height, width, core_region)
        length_offset = 10
        min_y_offset = floor(height * 0.15)
        max_y_offset = floor(height * 0.35)
        core_pad = int((core_region[1] - core_region[0]) * 0.1)
        x1 = np.random.randint(np.maximum(0, first_line[0][0] - length_offset), first_line[0][0] + length_offset)
        x2 = np.random.randint(first_line[1][0] - length_offset, np.minimum(width, first_line[1][0] + length_offset))
        center_third = floor(height * 0.3)
        top_third = floor(height * 0.6)
        y_avg = np.mean(first_line[:, 1])
        y1 = -1
        y2 = -1
        counter = 0
        while (y1 < core_region[0] - core_pad or y1 > core_region[1] + core_pad or y2 < core_region[
            0] - core_pad or y2 > core_region[1] + core_pad):
            if y_avg < center_third:
                y1 = first_line[0, 1] + np.random.randint(min_y_offset, max_y_offset)
                y2 = first_line[1, 1] + np.random.randint(min_y_offset, max_y_offset)
            elif y_avg > top_third:
                y1 = first_line[0, 1] - np.random.randint(min_y_offset, max_y_offset)
                y2 = first_line[1, 1] - np.random.randint(min_y_offset, max_y_offset)
            else:
                above = bool(np.random.randint(2))
                if above:
                    y1 = first_line[0, 1] + np.random.randint(min_y_offset, max_y_offset)
                    y2 = first_line[1, 1] + np.random.randint(min_y_offset, max_y_offset)
                else:
                    y1 = first_line[0, 1] - np.random.randint(min_y_offset, max_y_offset)
                    y2 = first_line[1, 1] - np.random.randint(min_y_offset, max_y_offset)
            counter += 1
            if counter > 5:
                # to avoid getting stuck for ever in some kind of unforseeable edge case: just take what we got after 5 tries
                logging.debug('double line gen exited with potentially less than optimal y values '
                              '(reason: exceeded loop limit)')
                break
        if x2 > width:
            x2 = width
        if y1 < 0:
            y1 = 0
        if y2 > height:
            y2 = height
        line_coords = np.append(first_line, [[x1, y1], [x2, y2]], axis=0)
        return line_coords

    def _cross(self, height, width, core_region=None):
        min_width = int(width * 0.75)
        x1 = np.random.randint(0, floor(width * 0.1))
        x2 = np.random.randint(x1 + min_width, width)
        x3 = np.random.randint(0, floor(width * 0.1))
        x4 = np.random.randint(x3 + min_width, width)

        y_positions = self._y_positions(height, 4, core_region=core_region)
        y1 = y_positions[0]
        y2 = y_positions[1]
        y3 = y_positions[3]
        y4 = y_positions[2]

        return np.array([[x1, y1], [x2, y2], [x3, y3], [x4, y4]])

    def _diagonal(self, height, width):
        top_half = floor(height * 0.5)
        min_width = int(width * 0.75)
        min_height = int(height * 0.25)

        y1 = np.random.randint(0, height)
        y2 = y1
        counter = 0
        while abs(y1 - y2) < min_height:
            if y1 > top_half:
                y2 = np.random.randint(0, top_half)
            else:
                y2 = np.random.randint(top_half, height)
            counter += 1
            if counter > 5:
                logging.debug('diagonal line gen exited with potentially(!) less than optimal y values '
                              '(reason: exceeded loop limit)')
                break

        x1 = np.random.randint(0, floor(width * 0.1))
        x2 = np.random.randint(x1 + min_width, width)
        return np.array([[x1, y1], [x2, y2]])

    def _wave(self, height: int, width: int, min_x_step: int = 10, max_x_step: int = 40, margin: int = 10,
              k: int = 2, core_region=None) -> np.ndarray:
        """Generates points along a wavy line.

        Parameters
        ----------
        height : int
            image height
        width : int
            image width
        min_x_step : int, optional
            minimum horizontal distance between two curve data points (default: 10)
        max_x_step : int, optional
            maximum horizontal distance between two curve data points (default: 40)
        margin : int, optional
            margin along the edges of the image in which no x and y positions will be generated (default: 10)
        k : int, optional
            B-spline degree (default: 2), see :func:'scipy.interpolate.BSpline' for more details

        Returns
        -------
        numpy.ndarray
            2D numpy.ndarray of wave coordinates (shape: (n, 2))
        """
        x = self._x_positions(width, min_x_step, max_x_step, margin)
        counter = 0
        while len(x) <= k:
            if counter > 2:
                x = self._x_positions(width, max_step=floor(width / k), margin=margin)
                counter += 1
            elif counter > 6:
                offset = k + 2
                x = [offset * i for i in range(1, k + 2)]
                logging.warning(
                    'wave gen issue: failed to generate sufficient x positions for image width {}, fell back to'
                    ' evenly spaced points'.format(width))
            else:
                x = self._x_positions(width, min_x_step, max_x_step, margin)
                counter += 1

        y = self._y_positions(height, len(x), margin=margin, core_region=core_region)
        tck = interpolate.splrep(x, y, k=k)
        spl = interpolate.BSpline(tck[0], tck[1], tck[2])
        xx = np.linspace(0, width, width * 2)
        yy = spl(xx)
        points = np.array(list(zip(xx, yy)), dtype=np.int64)
        point_filter = [False if p[0] < x[0] or p[0] > x[-1] else True for p in points]
        points = points[point_filter]
        return np.array(points)

    def _x_positions(self, width: int, min_step: int = 10, max_step: int = 50, margin: int = 5) -> list:
        """Generates an arbitrary number of x positions until the end of the image width is reached.

        Parameters
        ----------
        width:int
            image width
        min_step : int, optional
            minimum distance between two x positions (default: 10)
        max_step : int, optional
            maximum distance between two x positions (default: 50)
        margin : int, optional
            area in which no x positions will be generated (i.e. [0, margin] and [width-margin, width] (default: 5)

        Returns
        -------
        list
            list of x positions
        """
        positions = [np.random.randint(margin, margin + min_step)]

        while positions[-1] < (width - max_step):
            positions.append(positions[-1] + np.random.randint(min_step, max_step))
        return positions

    def _y_positions(self, height: int, count: int, margin: int = 10, core_region=None) -> List:
        """Generates the desired number of y positions alternating between the top and bottom half of the image.
        Randomly starts in either of the two halves.

        Parameters
        ----------
        height : int
            image height
        count : int
            number of points to generate
        margin : int, optional
            area in which no y positions will be generated (i.e. [0-margin] and [height-margin, height] (default:10)

        Returns
        -------
        List
            list of y positions
        """
        if core_region:
            diff = (core_region[1] - core_region[0])
            core_center = floor(core_region[1] - diff * 0.5)
        else:
            core_center = height * 0.5

        if height <= margin:
            margin = 0

        positions = [np.random.randint(margin, height - margin)]

        for _ in range(count - 1):
            if positions[-1] > core_center:
                if core_center <= margin:
                    positions.append(np.random.randint(0, core_center))
                else:
                    positions.append(np.random.randint(margin, core_center))
            else:
                if core_center >= height - margin:
                    positions.append(np.random.randint(core_center, height))
                else:
                    positions.append(np.random.randint(core_center, height - margin))
        return positions

    def _zig_zag(self, height, width, min_x_step=10, max_x_step=40, core_region=None):
        return self._wave(height, width, min_x_step, max_x_step, k=1, core_region=core_region)

    def _scratch(self, height, width, core_region, max_scratches=30, pad=10, y_offset=10):
        line_segments = []
        prev_x = np.random.randint(pad, width)
        if core_region[0] <= pad:
            prev_y = np.random.randint(0, max(core_region[0], 1))
        else:
            prev_y = np.random.randint(max(pad, core_region[0] - pad), core_region[0])

        center = width * 0.5

        line_segments.append([prev_x, prev_y])
        for i in range(max_scratches):
            if prev_x < center:
                next_x = np.random.randint(int(center) + pad, width - pad)
            else:
                next_x = np.random.randint(pad, int(center) - pad)

            next_y = prev_y + np.random.randint(-2, y_offset)
            if next_y > height - pad:
                return line_segments
            line_segments.append([next_x, next_y])
            prev_x = next_x
            prev_y = next_y
        return line_segments
